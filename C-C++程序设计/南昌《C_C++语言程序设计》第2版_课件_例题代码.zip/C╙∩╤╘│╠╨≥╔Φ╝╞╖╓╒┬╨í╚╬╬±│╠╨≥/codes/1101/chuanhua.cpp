#include<stdio.h>

#define PASTE(n) "abcdef"#n
#define NUM(a,b,c) a##b##c
#define STR(a,b,c) a##b##c

void main()
  {
  printf("%s\n",PASTE(15));
  printf("%d\n",NUM(1,2,3));
  printf("%s\n",STR("aa","bb","cc"));
  }
  